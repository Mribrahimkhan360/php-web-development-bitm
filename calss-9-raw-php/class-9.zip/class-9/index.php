<?php
require_once 'vendor/autoload.php';
use App\classes\Example;

$example = new Example();
$example->index();