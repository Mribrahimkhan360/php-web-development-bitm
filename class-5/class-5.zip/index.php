<?php
require_once 'vendor/autoload.php';
use App\classes\Home;
$helloWorld =new Home();
$helloWorld->index();